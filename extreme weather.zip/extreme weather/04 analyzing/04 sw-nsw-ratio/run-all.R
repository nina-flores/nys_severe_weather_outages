

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/04 sw-nsw-ratio")
source("04e - hours -with-outages-strata.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/04 sw-nsw-ratio")
source("04e - hours-w-storm-events-strata.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/04 sw-nsw-ratio")
source("04f - non-severe-hours-strata.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/04 sw-nsw-ratio")
source("04g - strata - unique.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/04 sw-nsw-ratio")
source("04h - co-ratios-stratified-updated.R")