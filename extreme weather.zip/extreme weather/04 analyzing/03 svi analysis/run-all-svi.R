

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("03a - extreme sw outages defined.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("03b - extreme sw outages defined 3.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("03c - extreme sw outages defined 5.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("03d - extreme sw outages defined yearly.R")

setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("04 - tmle-main.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("04 - tmle-svi-urn-specific-1-3-5.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("04b - tmle-by-year.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("05a - map region svi.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("06 - sw outage durations defined.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("07 - duration comparison.R")


setwd("~/Desktop/projects/casey cohort/power outages/severe weather PO NYS/code/extreme weather/04 analyzing/03 svi analysis")
source("08 duration comparison all.R")

