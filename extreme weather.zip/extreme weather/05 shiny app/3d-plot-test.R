library(plotly)

# create a vector of temperatures
expo <- seq(-15, 30, length.out = 31)
rr_temp <- matrix(rnorm(930), nrow = 31, ncol = 30)
df_temp <- data.frame(expo, rr_temp) %>%
  mutate(type = "temperature")

expo<- seq(0, 30, length.out = 31)
rr_wind <- matrix(rnorm(930), nrow = 31, ncol = 30)
df_wind <- data.frame(expo, rr_wind)%>%
  mutate(type = "wind")

expo <- seq(0, 5, length.out = 31)
rr_precip <- matrix(rnorm(930), nrow = 31, ncol = 30)
df_precip <- data.frame(expo, rr_precip)%>%
  mutate(type = "precipitation")

expo <- seq(0, 5, length.out = 31)
rr_snow <- matrix(rnorm(930), nrow = 31, ncol = 30)
df_snow <- data.frame(expo, rr_snow)%>%
  mutate(type = "snowfall")



df <- rbind(df_temp, df_wind,df_precip ,df_snow)


# convert the data frame to long format
df_long <- reshape2::melt(df, id.vars = c("expo", "type"), variable.name = "lag", value.name = "rr")

# convert the lag variable to numeric
df_long$lag <- as.numeric(gsub("X", "", df_long$lag))
df_long$urbanicity = "n"

data <- df_long



